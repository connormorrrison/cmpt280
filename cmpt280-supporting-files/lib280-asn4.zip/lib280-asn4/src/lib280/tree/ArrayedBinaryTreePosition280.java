package lib280.tree;

import lib280.base.CursorPosition280;

public class ArrayedBinaryTreePosition280 implements CursorPosition280 {
	protected int currentNode;
	
	public ArrayedBinaryTreePosition280(int pos) {
		currentNode = pos;
	}

}
